#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define STORE 1
#define LOAD 0

FILE *input = NULL;
FILE *output = NULL;
char *buff;
size_t buff_size = 256;

int prog_argc;
char o_path[256];
char i_path[256];

struct c_entry {
	int tag;
	int valid;
	int used;
};

typedef struct c_entry c_entry;

///
FILE *special_output = NULL;

void open_input() {
	if(input != NULL) {
		fclose(input);
		input = NULL;
	}
	
	if(prog_argc == 1 || prog_argc == 2) {
		fprintf(stderr, "Error, file name not specified on command line\n");
		exit(0);
	} else if (prog_argc != 3) {
		fprintf(stderr, "Error, too many arguments specified\n");

		exit(0);
	}

	
	input = fopen(i_path, "r");

	if(input == NULL) {
		fprintf(stderr, "Error, file name specified is not valid\n");
		exit(0);
	}
}

//Determines the address of the trace and the taken flag from a single line of
//input, returning them through the pointers passed in
void input_line(unsigned long *addr, int *sl, int *eof) {
	if(getline(&buff, &buff_size, input) == -1) {
		*eof = 1;
	} else {
		*eof = 0;
	
		int scale = 1;
		*addr = 0;
	
		//Converts the string for the address into an integer
		for(int i = 11; i >= 4; --i) {
			if(buff[i] >= 48 && buff[i] <= 57) {
				*addr += scale * (buff[i] - 48);
			} else if (buff[i] >= 97 && buff[i] <= 102) {
				*addr += scale * (buff[i] - 87);
			}
	
			scale *= 16;
		}

		if(buff[0] == 'S') {
			*sl = STORE;
		} else {
			*sl = LOAD;
		}
	}
}

void direct_mapped(int size) {
	size = size / 32;

	open_input();

	int hit_count = 0;
	int total_count = 0;

	unsigned long addr;
	int ls;
	int eof;

	int tag;
	int index;
	//int offset;

	input_line(&addr, &ls, &eof);

	c_entry table[size];

	for(int i = 0; i < size; ++i) {
		table[i].valid = 0;
		table[i].tag = 0;
	}

	int index_bits = 0;

	for(int i = size; i > 1; i = i >> 1) {
		++index_bits;
	}

	int offset_bits = 5;

	while(eof != 1) {
		tag = (addr >> (offset_bits + index_bits));
		index = ((addr >> (offset_bits)) & ((1 << index_bits) - 1));
		//offset = (addr & ((1 << offset_bits) - 1));

		++total_count;

		if((table[index].valid == 1) && (table[index].tag == tag)) {
			++hit_count;
		} else {
			table[index].tag = tag;
			table[index].valid = 1;
		}

		input_line(&addr, &ls, &eof);
	}

	fprintf(output, "%i,%i;", hit_count, total_count);
}

void set_associative(int ways) {
	int size = 512;

	size = size / ways;

	open_input();

	int hit_count = 0;
	int total_count = 0;

	unsigned long addr;
	int ls;
	int eof;

	int found = 0;
	int err = 0;
	int past_used;

	int tag;
	int index;
	//int offset;

	input_line(&addr, &ls, &eof);

	c_entry table[size][ways];

	for(int i = 0; i < size; ++i) {
		for(int i2 = 0; i2 < ways; ++i2) {
			table[i][i2].valid = 0;
			table[i][i2].tag = 0;
			table[i][i2].used = i2;
		}
	}

	int index_bits = 0;

	for(int i = size; i > 1; i = i >> 1) {
		++index_bits;
	}

	int offset_bits = 5;

	while(eof != 1) {
		tag = (addr >> (offset_bits + index_bits));
		index = ((addr >> (offset_bits)) & ((1 << index_bits) - 1));
		//offset = (addr & ((1 << offset_bits) - 1));

		++total_count;

		found = 0;

		err = 1;

		for(int i = 0; i < ways; ++i) {
			if(table[index][i].used < 0) {
				printf("-\n");
			}
			if((table[index][i].valid == 1) && (table[index][i].tag == tag)) {
				
				++hit_count;
				err = 0;
				found = 1;
				past_used = table[index][i].used;
				table[index][i].used = ways-1;
				for(int i2 = 0; i2 < ways; ++i2) {
					if(table[index][i2].used > past_used && i2 != i) {
						--table[index][i2].used;
					}
					if(table[index][i2].used < 0) {
						printf("-\n");
					}
				}

				
				break;
			}	
		}

		

		if(found == 0) {
			for(int i = 0; i < ways; ++i) {
				if(table[index][i].used < 0) {
					printf("-\n");
				}
				
				if(table[index][i].used == 0) {
					err = 0;
					past_used = table[index][i].used;
					table[index][i].used = ways-1;
					table[index][i].tag = tag;
					table[index][i].valid = 1;
					for(int i2 = 0; i2 < ways; ++i2) {
						if(table[index][i2].used > past_used && i2 != i) {
							--table[index][i2].used;
						}
						if(table[index][i2].used < 0) {
							printf("-\n");
						}
					}
					
					break;
				}
			}
		}
		
		if(err == 1) {
			printf("ERROR\n");
		}
		

		input_line(&addr, &ls, &eof);
	}

	fprintf(output, "%i,%i;", hit_count, total_count);
}

void fully_associative() {
	set_associative(512);
}

void fully_associative_hc() {
	int ways = 512;
	int size = 512;

	size = size / ways;

	open_input();

	int hit_count = 0;
	int total_count = 0;

	unsigned long addr;
	int ls;
	int eof;

	int found = 0;

	int hc[ways-1];

	for(int i = 0; i < ways-1; ++i) {
		hc[i] = 0;
	}

	int tag;
	//int index;
	//int offset;

	input_line(&addr, &ls, &eof);

	c_entry table[ways];

	for(int i = 0; i < ways; ++i) {
		table[i].valid = 0;
		table[i].tag = 0;
		table[i].used = 0;
	}

	int index_bits = 0;

	for(int i = size; i > 1; i = i >> 1) {
		++index_bits;
	}

	int offset_bits = 5;

	int coldest;

	int n;

	while(eof != 1) {
		tag = (addr >> (offset_bits + index_bits));
		
		//offset = (addr & ((1 << offset_bits) - 1));

		++total_count;

		found = 0;	

		for(int i = 0; i < ways; ++i) {
			if(table[i].used < 0) {
				printf("-\n");
			}
			if((table[i].valid == 1) && (table[i].tag == tag)) {
				
				++hit_count;
				found = 1;
				
				int i2 = 9;
				for(n = 0; n < ways-1;) {
					if((i & (1 << (i2 - 1))) > 0) {
						hc[n] = 1;
						n = 2*n + 2;	
					} else {
						hc[n] = 0;
						n = 2*n + 1;
					}
					--i2;
				}		
				break;
			}	
		}

		if(found == 0) {
			int temp;

			int i = 0;

			coldest = 0;
			for(n = 0; n < ways-1;) {
				coldest = (coldest << 1) | (1 - hc[n]);

				temp = n;

				if(hc[n] == 0) {
					n = 2*n + 2;
					hc[temp] = 1;
				} else {
					n = 2*n + 1;
					hc[temp] = 0;
				}

				++i;
			}

			table[coldest].valid = 1;
			table[coldest].tag = tag;

			/*for(int i2 = offset_bits; i2 > 0; --i2) {
				if((coldest & (1 << (i2 - 1))) > 0) {
					hc[n] = 1;
					n = 2*n + 2;	
				} else {
					hc[n] = 0;
					n = 2*n + 1;
				}
			}*/
		}
		
		/*if(err == 1) {
			printf("ERROR\n");
		}*/
		

		input_line(&addr, &ls, &eof);
	}

	fprintf(output, "%i,%i;", hit_count, total_count);
}

void set_associative_no_allo(int ways) {
	int size = 512;

	size = size / ways;

	open_input();

	int hit_count = 0;
	int total_count = 0;

	unsigned long addr;
	int ls;
	int eof;

	int found = 0;
	int past_used;

	int tag;
	int index;
	//int offset;

	input_line(&addr, &ls, &eof);

	c_entry table[size][ways];

	for(int i = 0; i < size; ++i) {
		for(int i2 = 0; i2 < ways; ++i2) {
			table[i][i2].valid = 0;
			table[i][i2].tag = 0;
			table[i][i2].used = i2;
		}
	}

	int index_bits = 0;

	for(int i = size; i > 1; i = i >> 1) {
		++index_bits;
	}

	int offset_bits = 5;

	while(eof != 1) {
		tag = (addr >> (offset_bits + index_bits));
		index = ((addr >> (offset_bits)) & ((1 << index_bits) - 1));
		//offset = (addr & ((1 << offset_bits) - 1));

		++total_count;

		found = 0;

		//err = 1;

		for(int i = 0; i < ways; ++i) {
			if(table[index][i].used < 0) {
				printf("-\n");
			}
			if((table[index][i].valid == 1) && (table[index][i].tag == tag)) {
				
				++hit_count;
				//err = 0;
				found = 1;
				past_used = table[index][i].used;
				table[index][i].used = ways-1;
				for(int i2 = 0; i2 < ways; ++i2) {
					if(table[index][i2].used > past_used && i2 != i) {
						--table[index][i2].used;
					}
					if(table[index][i2].used < 0) {
						printf("-\n");
					}
				}

				
				break;
			}	
		}

		

		if(found == 0 && ls == LOAD) {
			for(int i = 0; i < ways; ++i) {
				if(table[index][i].used < 0) {
					printf("-\n");
				}
				
				if(table[index][i].used == 0) {
					//err = 0;
					past_used = table[index][i].used;
					table[index][i].used = ways-1;
					table[index][i].tag = tag;
					table[index][i].valid = 1;
					for(int i2 = 0; i2 < ways; ++i2) {
						if(table[index][i2].used > past_used && i2 != i) {
							--table[index][i2].used;
						}
						if(table[index][i2].used < 0) {
							printf("-\n");
						}
					}
					
					break;
				}
			}
		}	
		

		input_line(&addr, &ls, &eof);
	}

	fprintf(output, "%i,%i;", hit_count, total_count);
}

void set_associative_pref(int ways) {
	int size = 512;

	size = size / ways;

	open_input();

	int hit_count = 0;
	int total_count = 0;

	unsigned long addr;
	int ls;
	int eof;

	int found = 0;
	int past_used;

	int tag;
	int index;
	//int offset;
	
	input_line(&addr, &ls, &eof);

	c_entry table[size][ways];

	for(int i = 0; i < size; ++i) {
		for(int i2 = 0; i2 < ways; ++i2) {
			table[i][i2].valid = 0;
			table[i][i2].tag = 0;
			table[i][i2].used = i2;
		}
	}

	int index_bits = 0;

	for(int i = size; i > 1; i = i >> 1) {
		++index_bits;
	}

	int offset_bits = 5;

	//
	int prev_index = -1;
	int prev_tag = -1;

	while(eof != 1) {
		tag = (addr >> (offset_bits + index_bits));
		index = ((addr >> (offset_bits)) & ((1 << index_bits) - 1));
		//offset = (addr & ((1 << offset_bits) - 1));

		++total_count;

		found = 0;

		for(int i = 0; i < ways; ++i) {
			if(table[index][i].used < 0) {
				printf("-\n");
			}
			if((table[index][i].valid == 1) && (table[index][i].tag == tag)) {
				
				++hit_count;
				//err = 0;
				found = 1;
				past_used = table[index][i].used;
				table[index][i].used = ways-1;
				for(int i2 = 0; i2 < ways; ++i2) {
					if(table[index][i2].used > past_used && i2 != i) {
						--table[index][i2].used;
					}
					if(table[index][i2].used < 0) {
						printf("-\n");
					}
				}

				
				break;
			}	
		}

		if((prev_index + 1) % size == index && found == 0 && (prev_tag == tag || prev_tag == tag - 1)) {
			++prev_index;
			--prev_index;
		}	

		if(found == 0) {
			for(int i = 0; i < ways; ++i) {
				if(table[index][i].used < 0) {
					printf("-\n");
				}
				
				if(table[index][i].used == 0) {
					//err = 0;
					past_used = table[index][i].used;
					table[index][i].used = ways-1;
					table[index][i].tag = tag;
					table[index][i].valid = 1;
					for(int i2 = 0; i2 < ways; ++i2) {
						if(table[index][i2].used > past_used && i2 != i) {
							--table[index][i2].used;
						}
						if(table[index][i2].used < 0) {
							printf("-\n");
						}
					}
					
					break;
				}
			}
		}
		
		prev_tag = tag;
		prev_index = index;

		found = 0;

		//++tag;
		addr = ((addr >> (offset_bits)) + 1) << offset_bits;

		tag = (addr >> (offset_bits + index_bits));
		index = ((addr >> (offset_bits)) & ((1 << index_bits) - 1));

		past_used = -1;
		int zero_count = 0;

		for(int i = 0; i < ways; ++i) {
			if((table[index][i].tag == tag) && (table[index][i].valid == 1)) {
				found = 1;

				past_used = table[index][i].used;
				table[index][i].used = ways-1;
				for(int i2 = 0; i2 < ways; ++i2) {
					if(table[index][i2].used > past_used && i2 != i) {
						--table[index][i2].used;
					} else if(table[index][i2].used == 0) {
						++zero_count;
					}
				}

				break;
			}
		}
		
		//
		if(found == 0) {
			for(int i = 0; i < ways; ++i) {
				if(table[index][i].used == 0) {
					past_used = table[index][i].used;
					table[index][i].used = ways-1;
					table[index][i].tag = tag;
					table[index][i].valid = 1;
					for(int i2 = 0; i2 < ways; ++i2) {
						if(table[index][i2].used > past_used && i2 != i) {
							--table[index][i2].used;
						} else if(table[index][i2].used == 0) {
							++zero_count;
						}
					}
					
					break;
				}
			}
		}

		if((past_used == -1 || zero_count > 1) && (found != 1)) {
			printf("ERR\n");
		}

		input_line(&addr, &ls, &eof);
	}

	fprintf(output, "%i,%i;", hit_count, total_count);
}

void set_associative_pref_miss(int ways) {
	int size = 512;

	size = size / ways;

	open_input();

	int hit_count = 0;
	int total_count = 0;

	unsigned long addr;
	int ls;
	int eof;

	int found = 0;
	int past_used;

	int tag;
	int index;
	//int offset;
	
	input_line(&addr, &ls, &eof);

	c_entry table[size][ways];

	for(int i = 0; i < size; ++i) {
		for(int i2 = 0; i2 < ways; ++i2) {
			table[i][i2].valid = 0;
			table[i][i2].tag = 0;
			table[i][i2].used = i2;
		}
	}

	int index_bits = 0;

	for(int i = size; i > 1; i = i >> 1) {
		++index_bits;
	}

	int offset_bits = 5;

	//
	int prev_index = -1;
	int prev_tag = -1;

	int prev_found;

	while(eof != 1) {
		tag = (addr >> (offset_bits + index_bits));
		index = ((addr >> (offset_bits)) & ((1 << index_bits) - 1));
		//offset = (addr & ((1 << offset_bits) - 1));

		++total_count;

		found = 0;

		for(int i = 0; i < ways; ++i) {
			if(table[index][i].used < 0) {
				printf("-\n");
			}
			if((table[index][i].valid == 1) && (table[index][i].tag == tag)) {
				
				++hit_count;
				//err = 0;
				found = 1;
				past_used = table[index][i].used;
				table[index][i].used = ways-1;
				for(int i2 = 0; i2 < ways; ++i2) {
					if(table[index][i2].used > past_used && i2 != i) {
						--table[index][i2].used;
					}
					if(table[index][i2].used < 0) {
						printf("-\n");
					}
				}

				
				break;
			}	
		}

		if((prev_index + 1) % size == index && found == 0 && (prev_tag == tag || prev_tag == tag - 1)) {
			++prev_index;
			--prev_index;
		}	

		if(found == 0) {
			for(int i = 0; i < ways; ++i) {
				if(table[index][i].used < 0) {
					printf("-\n");
				}
				
				if(table[index][i].used == 0) {
					//err = 0;
					past_used = table[index][i].used;
					table[index][i].used = ways-1;
					table[index][i].tag = tag;
					table[index][i].valid = 1;
					for(int i2 = 0; i2 < ways; ++i2) {
						if(table[index][i2].used > past_used && i2 != i) {
							--table[index][i2].used;
						}
						if(table[index][i2].used < 0) {
							printf("-\n");
						}
					}
					
					break;
				}
			}
		}
		
		prev_tag = tag;
		prev_index = index;

		prev_found = found;
		found = 0;

		//++tag;
		addr = ((addr >> (offset_bits)) + 1) << offset_bits;

		tag = (addr >> (offset_bits + index_bits));
		index = ((addr >> (offset_bits)) & ((1 << index_bits) - 1));

		past_used = -1;
		int zero_count = 0;
		
		if(prev_found == 0) {

		for(int i = 0; i < ways; ++i) {
			if((table[index][i].tag == tag) && (table[index][i].valid == 1)) {
				found = 1;

				past_used = table[index][i].used;
				table[index][i].used = ways-1;
				for(int i2 = 0; i2 < ways; ++i2) {
					if(table[index][i2].used > past_used && i2 != i) {
						--table[index][i2].used;
					} else if(table[index][i2].used == 0) {
						++zero_count;
					}
				}

				break;
			}
		}
		
		//
		if(found == 0) {
			for(int i = 0; i < ways; ++i) {
				if(table[index][i].used == 0) {
					past_used = table[index][i].used;
					table[index][i].used = ways-1;
					table[index][i].tag = tag;
					table[index][i].valid = 1;
					for(int i2 = 0; i2 < ways; ++i2) {
						if(table[index][i2].used > past_used && i2 != i) {
							--table[index][i2].used;
						} else if(table[index][i2].used == 0) {
							++zero_count;
						}
					}
					
					break;
				}
			}
		}

		}

		if((past_used == -1 || zero_count > 1) && (prev_found != 1)) {
			printf("ERR\n");
		}

		input_line(&addr, &ls, &eof);
	}

	fprintf(output, "%i,%i;", hit_count, total_count);
}

int main(int argc, char *argv[]) {

	prog_argc = argc;

	//EC
	//special_output = fopen("special_output.txt", "w");

	if(prog_argc == 1 || prog_argc == 2) {
		fprintf(stderr, "Error, file names not specified on command line\n");
		exit(0);
	} else if (prog_argc != 3) {
		fprintf(stderr, "Error, too many arguments specified\n");

		exit(0);
	}

	strcpy(o_path, argv[2]);
	
	strcpy(i_path, argv[1]);
	
	open_input();	

	output = fopen(o_path, "w");

	if(output == NULL) {
		fprintf(stderr, "Error, file name specified is not valid\n");
		exit(0);
	}

	buff = calloc(1, 256);
	
	//Start of prediction algorithms
	
	//Direct mapped
	direct_mapped(1024);
	fprintf(output, " ");
	direct_mapped(4096);
	fprintf(output, " ");
	direct_mapped(16384);
	fprintf(output, " ");
	direct_mapped(32768);
	fprintf(output, "\n");

	//Set-associative
	set_associative(2);
	fprintf(output, " ");
	set_associative(4);
	fprintf(output, " ");
	set_associative(8);
	fprintf(output, " ");
	set_associative(16);
	fprintf(output, "\n");

	//Fully associative
	fully_associative();
	fprintf(output, "\n");

	fully_associative_hc();
	fprintf(output, "\n");

	//Set-associatve, no allocation on write miss
	set_associative_no_allo(2);
	fprintf(output, " ");
	set_associative_no_allo(4);
	fprintf(output, " ");
	set_associative_no_allo(8);
	fprintf(output, " ");
	set_associative_no_allo(16);
	fprintf(output, "\n");

	//Set-associative, prefetching
	set_associative_pref(2);
	fprintf(output, " ");
	set_associative_pref(4);
	fprintf(output, " ");
	set_associative_pref(8);
	fprintf(output, " ");
	set_associative_pref(16);
	fprintf(output, "\n");

	//Set-associative, prefetch on miss
	set_associative_pref_miss(2);
	fprintf(output, " ");
	set_associative_pref_miss(4);
	fprintf(output, " ");
	set_associative_pref_miss(8);
	fprintf(output, " ");
	set_associative_pref_miss(16);
	fprintf(output, "\n");


	//End of program cleanup

	free(buff);

	fclose(output);

	//EC
	//fclose(special_output);
	
	if(input != NULL) {
		fclose(input);
	}
}
