Jared Leonard
B00715863

Seems to work with all cache methods required. No EC attempted.
